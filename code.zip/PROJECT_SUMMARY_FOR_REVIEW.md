# Project Summary for Report Review and Reproducible Submission

This file summarizes the project for an external reviewer or ChatGPT evaluator. It explains what the code does, how the components fit together, what experiments were run, and which files should be included in the final reproducible submission zip.

## Project Goal

The project is a Modern Game AI Algorithms final project about procedural content generation (PCG) and automated AI evaluation in a small turn-based tactical gridworld. The main question is whether generated maps are not only structurally valid, but also meaningfully different in difficulty, pacing, and skill expression for agents of different strength.

The project combines:

- a playable Pygame front end,
- a Griddly-backed game environment,
- procedural map generation,
- random, heuristic and MCTS agents,
- experiment runners,
- result analysis scripts and report figures.

## Game

The game is a turn-based tactical shooter on a rectangular 2D grid. The player wins by killing all enemies. The player loses when HP reaches zero or the experiment turn cap is reached.

Each player turn can include:

1. item activation,
2. movement,
3. attack,
4. enemy turns.

Enemies use breadth-first search/pathfinding to move toward the player and attack when adjacent. Movement and attacks are cardinal only. Walls block movement and line of sight.

### Terrain

- `hill`: increases the player's attack range by 1 while standing on it.
- `bush`: gives a 50% chance to cancel incoming enemy damage.
- `bunker`: absorbs 1 incoming damage once, then disappears.

### Items

- `dual_berettas`: allows a secondary attack while active.
- `shotgun`: increases range and doubles close-range damage.
- `golden_gun`: strong one-shot style effect implemented by repeated attack resolution.
- `vehicle`: allows extended movement while active.

## Core Code Files

- `play.py`: launches the playable Pygame version.
- `experiment.py`: main headless experiment runner. Supports smoke tests, single evaluations, PCG screening, OFAT sensitivity experiments, final validation and replays.
- `grid_battle/state.py`: immutable state/action dataclasses such as `BattleSnapshot`, `TurnAction` and `PhaseAction`.
- `grid_battle/combat.py`: combat constants, item/terrain names, direction helpers, line-of-sight helpers and unit profile logic.
- `grid_battle/game.py`: Griddly-backed real environment wrapper, turn encoding, HP tracking, item/terrain state and snapshots.
- `grid_battle/pcg.py`: procedural map generation, map sizes, map types, actor placement and structural validity checks.
- `grid_battle/agents.py`: random agent and heuristic baseline agent.
- `grid_battle/mcts.py`: MCTS/UCT agent, action enumeration, search profiles and rollout logic.
- `grid_battle/simulator.py`: custom forward model used by MCTS during planning.
- `grid_battle/ui_pygame.py`: Pygame interface and replay UI.

## Procedural Map Generation

PCG is implemented in `grid_battle/pcg.py`. The generator creates candidate maps, places actors/items/terrain, then validates the result before use.

Map types:

- `baseline`: scattered obstacle maps.
- `random_walk`: carved corridor-like maps with more chokepoints and longer routes.
- `arena`: more open maps with sparse mirrored obstacles.

Map sizes:

- `small`: 9 x 7, tutorial-like/easy.
- `medium`: 13 x 11, tuned balanced setting.
- `large`: 17 x 13, harder and longer setting.

Profiles used in experiments:

- enemy profile: `light`, `normal`, `medium_plus`, `heavy`;
- item profile: `few`, `normal`, `many`;
- wall profile: `open`, `normal`, `tight`.

Validity checks use BFS from the player start. A generated map is accepted only if enemies are reachable in the relevant tactical sense: the player can reach at least one tile from which each enemy can be attacked. The reachable area must also be large enough. These checks guarantee basic structural playability, but not balance.

## Agents

### Random Agent

The random agent selects legal moves and attacks randomly, and may activate an unused item with probability 0.5. It is used as a lower-bound sanity check.

### Heuristic Agent

The heuristic agent is a deterministic local baseline. It activates useful items, attacks immediately if possible, otherwise uses BFS to move toward a tile from which an enemy can be attacked. It also uses a second attack when dual berettas are active. It does not plan ahead beyond the current turn.

### MCTS Agent

The MCTS agent uses single-player UCT with a custom forward model. It searches over `TurnAction`s, including item activation, movement, primary attack and secondary attack when applicable. It uses the heuristic agent as rollout policy.

Profiles:

- `mcts_small`: 50 iterations per turn, rollout depth 10.
- `mcts_medium`: 200 iterations per turn, rollout depth 30.
- `mcts_strong`: 800 iterations per turn, rollout depth 40. Present in code but not part of the main final validation.

The forward model in `grid_battle/simulator.py` models terrain, items, active effects, vehicle movement, dual berettas, golden gun, shotgun, item pickup, bush dodge, bunker cover, enemy movement and effect ticking. It is still a separate planning model rather than direct Griddly stepping.

## Experiments

The main experiment runner is `experiment.py`. Experiments are headless and use the real Griddly-backed `GridBattleEnv`.

Main experiment suites:

- PCG screening: broad search over size, map type, enemy profile, item profile, wall profile and agent.
- Medium enemy tuning: targeted search over medium-map enemy profiles, introducing `medium_plus`.
- OFAT sensitivity: one-factor-at-a-time sensitivity around a tuned medium baseline, including combat parameters like player HP and enemy HP.
- Final validation: final selected generator defaults with more episodes per cell.

Important result files:

- `results/pcg_screening.csv`
- `results/medium_enemy_tuning.csv`
- `results/ofat_real.csv`
- `results/final_validation.csv`

Important analysis outputs:

- `results_analysis/pcg_screening/analysis_summary.md`
- `results_analysis/medium_enemy_tuning/analysis_summary.md`
- `results_analysis/ofat_real/ofat_analysis_summary.md`
- `results_analysis/final_validation/analysis_summary.md`
- `results_analysis/report_assets/figures/`
- `results_analysis/report_assets/tables/`
- `results_analysis/report_assets/screenshots/`

## Main Experimental Findings

- Small maps are easy/tutorial-like: heuristic and MCTS agents solve them reliably.
- Medium maps needed the `medium_plus` enemy profile because `normal` enemies were too easy and `heavy` enemies were often too harsh.
- Medium and large final settings create a clear skill gap between heuristic and MCTS-medium.
- Matched-seed comparisons show that MCTS-medium solves many maps that the heuristic fails on the same generated seeds.
- Random-walk maps tend to have more chokepoints and longer games.
- Win rate alone is not enough; pacing, damage, final HP, remaining enemies and structural metrics matter.
- Player HP and enemy HP are highly sensitive, so final PCG validation fixes combat HP and focuses on generator-facing controls.

## Key Commands

Install:

```bash
python3.11 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

Play:

```bash
python play.py
python play.py --size medium --map-type random_walk --seed 42
```

Smoke test:

```bash
python experiment.py smoke --workers 4
```

Final validation:

```bash
python experiment.py final-validation \
  --episodes 50 \
  --workers 16 \
  --overwrite \
  --csv-out results/final_validation.csv
```

Analyze final validation:

```bash
python results_analysis/analyze_pcg_results.py \
  results/final_validation.csv \
  --out-dir results_analysis/final_validation
```

Run all major experiments if recomputing from scratch:

```bash
python experiment.py pcg-screen --episodes 20 --workers 16 --overwrite --csv-out results/pcg_screening.csv
python experiment.py pcg-screen --episodes 30 --workers 16 --sizes medium --map-types baseline,random_walk,arena --enemy-profiles normal,medium_plus,heavy --item-profiles normal,many --wall-profiles open,normal --agents random,heuristic,mcts_small,mcts_medium --overwrite --csv-out results/medium_enemy_tuning.csv
python experiment.py ofat --episodes 30 --workers 16 --overwrite --csv-out results/ofat_real.csv
python experiment.py final-validation --episodes 50 --workers 16 --overwrite --csv-out results/final_validation.csv
```

## Essential Files for a 10/10 Reproducible Submission Zip

Include these files/directories:

- `README.md`
- `PROJECT_SUMMARY_FOR_REVIEW.md`
- `requirements.txt`
- `play.py`
- `experiment.py`
- `grid_battle/`
- `assets/sprites/`
- `results/pcg_screening.csv`
- `results/medium_enemy_tuning.csv`
- `results/ofat_real.csv`
- `results/final_validation.csv`
- `results/replays/` if space allows, for example runs/replays used for debugging or demonstration.
- `results_analysis/analyze_pcg_results.py`
- `results_analysis/analyze_ofat_results.py`
- `results_analysis/make_report_assets.py`
- `results_analysis/pcg_analysis_notebook.ipynb`
- `results_analysis/pcg_screening/`
- `results_analysis/medium_enemy_tuning/`
- `results_analysis/ofat_real/`
- `results_analysis/final_validation/`
- `results_analysis/report_assets/`
- final report PDF, currently `MGAA_A3_real.pdf`
- final report source files if required by the course, especially the actual `.tex` source used to produce the final PDF and any referenced figures/tables.

Optional but useful:

- `EXPERIMENT_LOG.md`
- `MGAIA__Final_Project_Proposal.pdf`
- `mgaa-project-setup.pdf` if you want the grader to see the assignment setup locally, though it is not part of the project implementation.

Exclude these from the zip:

- `.git/`
- `.venv/`
- `.idea/`
- `__pycache__/`
- `.DS_Store`
- local diagnostic scripts unless specifically needed: `mac_diagnostic.sh`, `mac_disk_analysis.sh`
- temporary or duplicate TeX drafts that are not part of the final report source.

## Suggested Zip Command

From the repository root:

```bash
zip -r MGAA_Group8_Final_Submission.zip \
  README.md PROJECT_SUMMARY_FOR_REVIEW.md requirements.txt \
  play.py experiment.py grid_battle assets \
  results results_analysis \
  MGAA_A3_real.pdf EXPERIMENT_LOG.md \
  -x "*/__pycache__/*" "*.DS_Store" ".git/*" ".venv/*" ".idea/*"
```

If the final report source is required, add the actual final `.tex` source and its report figures. Do not include stale draft TeX files unless they are clearly labelled as drafts.

## Things a Reviewer Should Check in the Final Report

- Abstract and keywords are filled in.
- The final PDF is at or below the 20-page limit.
- The balance-score equation matches the code:

```text
s = 1.0 - |w_M - 0.80| - 0.7|w_H - 0.50| + 0.6(w_M - w_H) - 0.5w_R
```

- The AI Agents section accurately states that MCTS includes item activation in its action space.
- The MCTS forward model is described as high-fidelity but still separate from Griddly.
- The report explicitly connects the project to at least three course topics: PCG, MCTS/search-based game AI and experimentation/evaluation. Evolutionary/search-based PCG can be mentioned as future work if not implemented.
- Generative AI use is documented.

